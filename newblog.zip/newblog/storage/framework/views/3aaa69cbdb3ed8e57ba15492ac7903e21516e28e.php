<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startPush('css'); ?>
<style>
   td img { display: block; }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content_header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          School Master
        
      </h1>
     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
             
            </div>
            <!-- /.box-header -->
            <div class="">
            <a href="<?php echo e(route('school.create')); ?>" class="btn btn-success align-right">Add New</a>
            </div>
            <!-- form start -->
            <form role="form">
              <div class="box-body">
                <table class="table table-striped">
                    <thead>
                        <th>No</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Phone NO</th>
                        <th>Email</th>
                        <th>Principal</th>
                        <th>Owner</th>
                        <th>Image</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $school; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($value->name ?? ""); ?></td>
                        <td><?php echo e($value->address ?? ""); ?></td>
                        <td><?php echo e($value->phone ?? ""); ?></td>
                        <td><?php echo e($value->email ?? ""); ?></td>
                        <td><?php echo e($value->principal ?? ""); ?></td>
                        <td><?php echo e($value->owner ?? ""); ?></td>
                        <td> <img src="<?php echo e(URL::asset('storage/uploads/school/thumbnails/'.$value->image)); ?>" class="img-circle thumbnail" alt="" width="20%" ></td>
                        <td><?php echo e($value->created_at ->diffForHumans() ?? ""); ?></td>
                        <td><?php echo e($value->updated_at ->diffForHumans() ?? ""); ?></td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                
                                <a href="<?php echo e(route('school.edit',$value->id)); ?>" class="edit-model btn btn-warning btn-sm " >
                                    <i class="fa fa-edit"></i>
                                    </a>
                                    <button class="delete-model btn btn-danger btn-sm " type="button" onclick="deleteSchool(<?php echo e($value->id); ?>)">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                        <form id="delete-form-<?php echo e($value->id); ?>" action="<?php echo e(route('school.destroy',$value->id)); ?>" method="POST" style="display: none;">
                                                                          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                                      </form>
                                </div>
            
                        </td>
                        
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
              
              <!-- /.box-body -->

          </div>
          <!-- /.box -->

        
        <!--/.col (right) -->
      </div>
    </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  
  <!-- /.content-wrapper -->
       
<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
    <script>

        $(document).ready(function() {
            $('#example1').DataTable();
        } );

    </script>
    <script type="text/javascript">
      function deleteSchool(id) {
       const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-danger'
      },
      buttonsStyling: false
    })
    
    swalWithBootstrapButtons.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true
    }).then((result) => {
      if (result.value) {
        event.preventDefault();
          document.getElementById('delete-form-'+id).submit();
          alert(id);
      } else if (
        /* Read more about handling dismissals below */
        result.dismiss === Swal.DismissReason.cancel
      ) {
        swalWithBootstrapButtons.fire(
          'Cancelled',
          'Your imaginary file is safe :)',
          'error'
        )
      }
    })
      }</script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>