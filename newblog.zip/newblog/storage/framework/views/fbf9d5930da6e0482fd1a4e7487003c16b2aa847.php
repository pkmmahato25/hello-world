<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Category</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box-body">
        <div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap">
            <div class="row">
                <div class="col-xs-12">
                  <div class="box">
                    <div class="box-header">
                      <h3 class="box-title">Hover Data Table</h3>
                    </div>
                    <!-- /.box-header -->
                    <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="alert alert-danger alert-dismissible">
                                <button class="close" aria-hidden="true" type="button" data-dismiss="alert">×</button>
                                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                                <?php echo e($errors); ?>

                              </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>
                    <div class="box-body">
                        <div class="col-md-6">
                    <form action="<?php echo e(route('category.store')); ?>" enctype="multipart/form-data" method="POST">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="form-group">
                            <label for="category">Category Name</label>
                        <input type="text" class="form-control"name="categoryname" id="category" value="">
                        </div>
                        <input type="submit" value="Save" class="btn btn-success">
                    </div>
                           
                        </form>
                    </div>
                  </div>
                </div>
            </div>
        </div>
    </div>
            
        
   
       
<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>