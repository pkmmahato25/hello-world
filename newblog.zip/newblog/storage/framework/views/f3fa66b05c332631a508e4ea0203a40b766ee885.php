<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Category <a href="<?php echo e(route('category.create')); ?>" class="btn btn-success">Create</a></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box-body">
        <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
            <div class="row">
                <div class="col-xs-12">
                  <div class="box">
                    <div class="box-header">
                      <h3 class="box-title">Hover Data Table</h3>
                    </div>
                    <!-- /.box-header -->
                  
                    <div class="box-body">
                       
                        <table id="example1" class="table table-hover responsive">
                            <thead>
                                <th>NO</th>
                                <th>Name</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($value->name); ?></td>
                                <td>
                                <button class="btn btn-primary">View</button>
                                <a href="<?php echo e(route('category.edit',$value->id)); ?>" class="btn btn-success">Edit</a>
                                <button class="btn btn-danger">Delete</button>
                            </td>
                        </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
            
        
   
       
<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
    <script>

        $(document).ready(function() {
            $('#example1').DataTable();
        } );

    </script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>